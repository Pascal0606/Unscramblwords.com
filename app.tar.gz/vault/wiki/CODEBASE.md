tyled with Tailwind + shadcn/ui-style component primitives. The app is a multilingual "Word Unscrambler" web UI with blog pages, privacy policy, cookie consent banner, and a client-side word unscrambling engine that uses in-memory dictionaries and (for non-English) fetches word lists from remote sources via CORS proxies.

## apps/web (React + Vite + Tailwind + React Router, port 3000)

### Entry points / bootstrapping
- `apps/web/index.html` — HTML shell, SEO/meta tags, AdSense script, root mount (`/src/main.jsx`)
- `apps/web/src/main.jsx` — ReactDOM bootstrap + global CSS import
- `apps/web/src/App.jsx` — React Router routes for language landing pages, blog, blog articles, and privacy policy

### Routing / pages
- `apps/web/src/App.jsx` — Routes:
  - `/privacy`
  - `/blog`, `/blog/:slug`
  - `/<lang>/blog`, `/<lang>/blog/:slug` for `en|fr|de|it|es|pt|tr|ru|zh|ar`
  - `/<lang>` (language landing page that renders the unscrambler)
  - `/` and `*` redirect to `/en`
- `apps/web/src/pages/UnscrambleApp.jsx` — Main unscrambler UI (input, filters, results, scoring, animations); all `calculateScrabblePoints` calls pass `currentLanguage` as second argument
- `apps/web/src/pages/PrivacyPolicy.jsx` — Privacy policy page with Helmet meta tags
- `apps/web/src/pages/Blog.jsx` — Blog listing + article rendering logic (uses `useParams` for `:slug`)
- `apps/web/src/pages/BlogArticle.jsx` — Re-export shim for `Blog.jsx` (default export)
- `apps/web/src/pages/HomePage.jsx` — Placeholder (empty component)

### Core app logic (unscrambling + scoring)
- `apps/web/src/hooks/useWordUnscrambler.js` — Unscramble engine:
  - Maintains `filters` state (startsWith/endsWith/contains/requiredLetter/wordLength)
  - Uses dictionary selection:
    - English: `NWL_WORDS | CSW_WORDS | ENABLE_WORDS` from `@/lib/dictionaries.js` (note: file currently exports `DICTIONARIES` and a large `BASE_WORDS` list; the referenced exports are not shown in provided snippet)
    - Non-English: fetches remote word lists per language via CORS proxies (`fetchDictionary`)
  - Filters results by letter inclusion + advanced filters
- `apps/web/src/lib/calculateScrabblePoints.js` — Language-specific Scrabble letter scoring:
  - Per-language letter-value tables: English, French, Spanish (with digraphs LL/RR), German, Italian, Portuguese, Turkish (with dotted İ / dotless I handling), Russian (Cyrillic)
  - Chinese and Arabic return 0 (pending user scoring rules)
  - Accepts `(word, language)` parameters
- `apps/web/src/lib/dictionaries.js` — Dictionary data source (exports `DICTIONARIES` and large `BASE_WORDS`; referenced `ENABLE_WORDS/NWL_WORDS/CSW_WORDS` not visible in provided snippet)
- `apps/web/src/lib/languageDictionaries.js` — (Not shown in provided snippet) referenced by `useWordUnscrambler`? (Not present; instead there are multiple `languageDictionaries*.js` files)
- `apps/web/src/lib/languageDictionaries1.js` — Spanish/French word lists (`ES_WORDS`, `FR_WORDS`)
- `apps/web/src/lib/languageDictionaries2.js` — Portuguese/Italian word lists (`PT_WORDS`, `IT_WORDS`) (and truncated content)
- `apps/web/src/lib/languageDictionaries3.js` — Russian/Chinese/Arabic word lists (`RU_WORDS`, `ZH_WORDS`, `AR_WORDS`) + `LANGUAGE_DICTIONARIES` + `getDictionaryForLanguage`
- `apps/web/src/lib/languageDictionaries.js` — Small sample dictionary per language (`LANGUAGE_DICTIONARIES` with short word arrays)
- `apps/web/src/lib/FrWordsFull.js` — French word list (empty placeholder)

### Internationalization (i18n)
- `apps/web/src/context/LanguageContext.jsx` — `LanguageProvider` + `useLanguage`:
  - Chooses `currentLanguage` from `translations[lang]` else defaults to `en`
  - Provides `t(path, params)` lookup with fallback to English
- `apps/web/src/hooks/useLanguage.js` — Thin wrapper around `useLanguage` context
- `apps/web/src/i18n/translations.js` — Translation dictionary for UI strings + help text (large; truncated in provided snippet)
- `apps/web/src/i18n/blogContent.js` — Blog article content per language (English shown; truncated)
- `apps/web/src/i18n/languageDetection.js` — Browser language detection for supported languages
- `apps/web/src/i18n/i18n.js` — i18n helper exports (supported languages, detectLanguage)

### UI components (app-level)
- `apps/web/src/components/UnscrambleApp` (inlined in page) — Main UI is implemented inside `apps/web/src/pages/UnscrambleApp.jsx`
- `apps/web/src/components/WordCard.jsx` — Result card:
  - Click-to-copy word to clipboard
  - Uses `sonner` toast + localized strings via `useLanguage`
- `apps/web/src/components/HelpSection.jsx` — Help & FAQ section (uses `useLanguage`)
- `apps/web/src/components/LanguageSelector.jsx` — Language dropdown (navigates to `/${langCode}`)
- `apps/web/src/components/FilterPanel.jsx` — Filter chips summary + "Clear Filters" button
- `apps/web/src/components/ScrabbleBackground.jsx` — Decorative blurred tile background
- `apps/web/src/components/ScrabbleTileTitle.jsx` — "MY WORD / UNSCRAMBLER" tile title animation
- `apps/web/src/components/CookieConsentBanner.jsx` — Cookie consent banner (sessionStorage-based)
- `apps/web/src/components/BackgroundLayer.jsx` — Radial gradient blur background layer
- `apps/web/src/components/ScrollToTop.jsx` — Scroll-to-top on route change (not wired in shown routes)
- `apps/web/src/components/ui/*` — shadcn/ui-style primitives (Button, Card, Dialog, Select, etc.)

### UI primitives / infrastructure components
- `apps/web/src/components/ui/button.jsx` — Button variants/sizes
- `apps/web/src/components/ui/input.jsx` — Text input
- `apps/web/src/components/ui/label.jsx` — Label
- `apps/web/src/components/ui/select.jsx` — Radix Select wrapper
- `apps/web/src/components/ui/card.jsx` — Card layout primitives
- `apps/web/src/components/ui/dialog.jsx` — Radix Dialog wrapper
- `apps/web/src/components/ui/accordion.jsx` — Radix Accordion wrapper
- `apps/web/src/components/ui/tooltip.jsx` — Radix Tooltip wrapper
- `apps/web/src/components/ui/toaster.jsx` + `apps/web/src/components/ui/sonner.jsx` — Toast UI integration
- `apps/web/src/components/ui/skeleton.jsx` — Skeleton placeholder
- `apps/web/src/components/ui/scroll-area.jsx` — Radix ScrollArea wrapper
- `apps/web/src/components/ui/progress.jsx` — Radix Progress wrapper
- `apps/web/src/components/ui/checkbox.jsx`, `radio-group.jsx`, `switch.jsx` — Form controls
- `apps/web/src/components/ui/table.jsx` — Table primitives
- `apps/web/src/components/ui/pagination.jsx` — Pagination primitives
- `apps/web/src/components/ui/*` — Many additional Radix/utility components (carousel, chart, drawer, sheet, etc.)

### Hooks / utilities
- `apps/web/src/hooks/use-mobile.jsx` — Mobile breakpoint detection for sidebar behavior
- `apps/web/src/hooks/use-toast.js` — Custom toast state management (used by `components/ui/toaster.jsx`)
- `apps/web/src/lib/utils.js` — `cn()` helper (clsx + tailwind-merge)

### Styling / Tailwind / PostCSS
- `apps/web/src/index.css` — Tailwind base + theme CSS variables + custom classes (scrabble tiles, help section, animations)
- `apps/web/tailwind.config.js` — Tailwind theme extensions (colors mapped to CSS variables)
- `apps/web/postcss.config.js` — Tailwind + autoprefixer

### Static assets / SEO
- `apps/web/public/ads.txt` — AdSense publisher mapping
- `apps/web/public/sitemap-*.xml` — Language-specific sitemaps (en/es/fr/de/it/pt/ru/tr/zh/ar shown)
- `apps/web/public/*` — Other public files referenced by HTML (e.g., `/favicon.svg`, `og-image.png` referenced in meta tags)

### Build / Vite configuration (infrastructure)
- `apps/web/vite.config.js` — Vite config with custom plugins (visual editor, selection mode, iframe route restoration, site pages, PocketBase auth) and runtime/error handlers (horizons integration)

### Routes:
- Unscrambler landing: `/<lang>` (renders `UnscrambleApp` within `LanguageProvider`)
- Blog listing: `/<lang>/blog` and `/blog`
- Blog article: `/<lang>/blog/:slug` and `/blog/:slug`
- Privacy policy: `/privacy`
- Redirects: `/` and `*` → `/en`
