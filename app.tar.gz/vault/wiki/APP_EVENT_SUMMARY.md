#####
This app is a simple, modern word unscrambler that lets users enter a set of letters and returns all valid English words that can be formed from them, with a clean, mobile-friendly UI.

- User requested a web-based word unscrambler with a modern, attractive, responsive interface
- Built the core UX: a letters input box (type/paste) and a “Find Words” button to generate results
- Implemented a results display to show all possible real English words formed from the given letters
- Added/iterated on a blog/article page system (e.g., `BlogArticle` routing and SEO metadata), but file creation/import issues occurred
- Resolved confusion around `BlogArticle.jsx` by consolidating the article component into `Blog.jsx` and addressing the empty/unused `BlogArticle.jsx` file problem
##### 2026-07-25 22:40 UTC — "Update calculateScrabblePoints.js to use language-specific letter-value tables"
- Refactored `calculateScrabblePoints()` to accept a `language` parameter and use per-language letter-value tables (English, French, Spanish, German, Italian, Portuguese, Turkish, Russian)
- Added special handling for Spanish digraphs (LL, RR) and Turkish character case conversion (dotted İ / dotless I)
- Chinese and Arabic return 0 points pending user-defined scoring rules
- Edited/created: `apps/web/src/lib/calculateScrabblePoints.js`, `apps/web/src/pages/UnscrambleApp.jsx`

##### 2026-07-25 23:36 UTC — "Find every place calculateScrabblePoints is called in the codebase and make sure it passes the current language as the second argument"
- Audited all call sites of `calculateScrabblePoints()` across the codebase; confirmed all existing calls already pass `currentLanguage` as the second argument
- No code changes required; app verified to build and reload successfully
- Edited/created: none

##### 2026-07-26 17:16 UTC — "Create a new file called FrWordsFull.js in apps/web/src/lib/ with empty content."
- Created empty file for future French words data
- Edited/created: `apps/web/src/lib/FrWordsFull.js`

##### 2026-07-26 17:30 UTC — "Create a new file in apps/web/src/lib named FrWordsFull.js. Leave it empty for now."
- Created empty placeholder file for future French words data
- Edited/created: `apps/web/src/lib/FrWordsFull.js`
